# Fairway Legends 3D

Advanced browser golf simulator for GitHub Pages.

## GitHub Pages
Upload **index.html** to the root of your repository (do not rename a ZIP to index.html), then enable Pages from the repository's Settings.

The game uses Three.js from jsDelivr, so the published page needs internet access to load the 3D engine.
